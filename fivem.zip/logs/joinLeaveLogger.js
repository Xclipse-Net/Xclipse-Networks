const { Events } = require('discord.js');

module.exports = (client) => {
  client.on(Events.GuildMemberAdd, member => {
    const logChannel = member.guild.channels.cache.find(ch => ch.name === 'join-logs');
    if (logChannel) {
      logChannel.send(`✅ **${member.user.tag}** joined the server.`);
    }
  });

  client.on(Events.GuildMemberRemove, member => {
    const logChannel = member.guild.channels.cache.find(ch => ch.name === 'join-logs');
    if (logChannel) {
      logChannel.send(`❌ **${member.user.tag}** left the server.`);
    }
  });
};
