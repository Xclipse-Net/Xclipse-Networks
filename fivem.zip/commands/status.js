const { SlashCommandBuilder } = require('discord.js');
const axios = require('axios');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('status')
    .setDescription('Check FiveM server status'),
  async execute(interaction) {
    try {
      const res = await axios.get(process.env.FIVEM_API);
      const players = res.data;
      await interaction.reply(`🟢 Server Online: ${players.length} players connected.`);
    } catch (err) {
      await interaction.reply('🔴 Server Offline or unreachable.');
    }
  },
};
