const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Kick a player by Discord ID or Steam ID')
    .addStringOption(option =>
      option.setName('id')
        .setDescription('Enter the Steam/Discord ID')
        .setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),
  async execute(interaction) {
    const playerId = interaction.options.getString('id');
    // Kick logic here (e.g., send request to server API)
    await interaction.reply(`👢 Kicked ID: ${playerId}`);
  },
};
