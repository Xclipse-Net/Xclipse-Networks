const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('whitelist')
    .setDescription('Whitelist a player by Discord ID or Steam ID')
    .addStringOption(option =>
      option.setName('id')
        .setDescription('Enter the Steam/Discord ID')
        .setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),
  async execute(interaction) {
    const playerId = interaction.options.getString('id');
    // Here, integrate your actual whitelist logic (e.g., DB or file-based)
    await interaction.reply(`✅ Whitelisted ID: ${playerId}`);
  },
};
