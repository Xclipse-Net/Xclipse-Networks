const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Ban a player by Discord ID or Steam ID')
    .addStringOption(option =>
      option.setName('id')
        .setDescription('Enter the Steam/Discord ID')
        .setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),
  async execute(interaction) {
    const playerId = interaction.options.getString('id');
    // Hook into your server-side ban system here
    await interaction.reply(`⛔ Banned ID: ${playerId}`);
  },
};
